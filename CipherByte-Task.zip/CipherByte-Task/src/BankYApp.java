import java.util.HashMap;
import java.util.Scanner;

class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    private double balance;

    public BankAccount(String accountNumber, String accountHolderName) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: $" + amount);
        } else {
            System.out.println("Invalid amount. Please enter a positive value.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: $" + amount);
        } else {
            System.out.println("Invalid transaction. Either insufficient funds or invalid amount.");
        }
    }

    public void transfer(BankAccount recipient, double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            recipient.deposit(amount);
            System.out.println("Transferred: $" + amount + " to " + recipient.getAccountHolderName());
        } else {
            System.out.println("Invalid transfer. Either insufficient funds or invalid amount.");
        }
    }

    @Override
    public String toString() {
        return "Account Holder: " + accountHolderName + ", Account Number: " + accountNumber + ", Balance: $" + balance;
    }
}

class BankY {
    private HashMap<String, BankAccount> accounts = new HashMap<>();

    public void createAccount(String accountNumber, String accountHolderName) {
        if (!accounts.containsKey(accountNumber)) {
            BankAccount account = new BankAccount(accountNumber, accountHolderName);
            accounts.put(accountNumber, account);
            System.out.println("Account created successfully for " + accountHolderName);
        } else {
            System.out.println("Account number already exists. Please choose a different account number.");
        }
    }

    public BankAccount getAccount(String accountNumber) {
        if (accounts.containsKey(accountNumber)) {
            return accounts.get(accountNumber);
        } else {
            System.out.println("Account not found.");
            return null;
        }
    }

    public void listAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
        } else {
            for (BankAccount account : accounts.values()) {
                System.out.println(account);
            }
        }
    }
}

public class BankYApp {
    public static void main(String[] args) {
        BankY bank = new BankY();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWelcome to BankY:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit Funds");
            System.out.println("3. Withdraw Funds");
            System.out.println("4. Transfer Funds");
            System.out.println("5. List All Accounts");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter account holder's name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter account number: ");
                    String accNumber = scanner.nextLine();
                    bank.createAccount(accNumber, name);
                    break;
                case 2:
                    System.out.print("Enter account number: ");
                    accNumber = scanner.nextLine();
                    BankAccount depositAccount = bank.getAccount(accNumber);
                    if (depositAccount != null) {
                        System.out.print("Enter amount to deposit: ");
                        double depositAmount = scanner.nextDouble();
                        depositAccount.deposit(depositAmount);
                    }
                    break;
                case 3:
                    System.out.print("Enter account number: ");
                    accNumber = scanner.nextLine();
                    BankAccount withdrawAccount = bank.getAccount(accNumber);
                    if (withdrawAccount != null) {
                        System.out.print("Enter amount to withdraw: ");
                        double withdrawAmount = scanner.nextDouble();
                        withdrawAccount.withdraw(withdrawAmount);
                    }
                    break;
                case 4:
                    System.out.print("Enter your account number: ");
                    String fromAccNumber = scanner.nextLine();
                    BankAccount fromAccount = bank.getAccount(fromAccNumber);
                    if (fromAccount != null) {
                        System.out.print("Enter recipient's account number: ");
                        String toAccNumber = scanner.nextLine();
                        BankAccount toAccount = bank.getAccount(toAccNumber);
                        if (toAccount != null) {
                            System.out.print("Enter amount to transfer: ");
                            double transferAmount = scanner.nextDouble();
                            fromAccount.transfer(toAccount, transferAmount);
                        }
                    }
                    break;
                case 5:
                    bank.listAccounts();
                    break;
                case 6:
                    System.out.println("Exiting BankY. Have a great day!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        }
    }
}
